#include <iostream>
#include <omp.h>

void matrixMulNaive(float* A, float* B, float* C, int N) {

    for (int i = 0; i < N; i++) {
	for (int j = 0; j < N; j++) {    
            float sum = 0.0f;
            for (int l = 0; l < N; l++) {
            	sum += A[i * N + l] * B[l * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

int main(int argc,char *argv[])
{	
    long N = (argc > 1) ? atol(argv[1]) : 512; // Matrix size (512x512)
    int threads = (argc > 2) ? atol(argv[2]) : 16;
  
    size_t size = N * N * sizeof(float);
    // 1. Allocate Host memory (CPU)
    float *h_A = (float*)malloc(size);
    float *h_B = (float*)malloc(size);
    float *h_C = (float*)malloc(size);

    // Initialize matrices with some data
    for (int i = 0; i < N * N; i++) {
        h_A[i] = 1.0f; 
        h_B[i] = 2.0f;
    }


    double start =  omp_get_wtime();
    matrixMulNaive(h_A, h_B, h_C, N);
    double gpu_time = omp_get_wtime() - start;

    // Verify a small piece of the result
    std::cout << "Result at C[0]: " << h_C[0] << " (Expected: " << (float)N * 2.0f << ")" << std::endl;
    std::cout << "Compute time: " << gpu_time << " GFLOPS: " << N*N*N*2/gpu_time/1000000000  << std::endl;
    // 7. Cleanup
    free(h_A);
    free(h_B);
    free(h_C);

    return 0;
}
