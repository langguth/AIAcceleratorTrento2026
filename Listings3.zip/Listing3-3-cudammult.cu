#include <iostream>
#include <cuda_runtime.h>
#include <omp.h>

// CUDA Kernel: Naive Matrix Multiplication
__global__ void matrixMulNaive(float* A, float* B, float* C, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < N && col < N) {
        float sum = 0.0f;
        for (int l = 0; l < N; l++) {
            sum += A[row * N + l] * B[l * N + col];
        }
        C[row * N + col] = sum;
    }
}

int main(int argc,char *argv[])
{	
    long N = (argc > 1) ? atol(argv[1]) : 512; // Matrix size (512x512)
    int threads = (argc > 2) ? atol(argv[2]) : 16;
  
    size_t size = N * N * sizeof(float);
    // 1. Allocate Host memory (CPU)
    float *h_A = (float*)malloc(size);
    float *h_B = (float*)malloc(size);
    float *h_C = (float*)malloc(size);

    // Initialize matrices with some data
    for (int i = 0; i < N * N; i++) {
        h_A[i] = 1.0f; 
        h_B[i] = 2.0f;
    }

    // 2. Allocate Device memory (GPU)
    float *d_A, *d_B, *d_C;
    cudaMalloc(&d_A, size);
    cudaMalloc(&d_B, size);
    cudaMalloc(&d_C, size);

    // 3. Copy data from Host to Device
    cudaMemcpy(d_A, h_A, size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_B, h_B, size, cudaMemcpyHostToDevice);

    // 4. Define Launch Parameters
    dim3 threadsPerBlock(threads, threads);
    dim3 blocksPerGrid((N + threadsPerBlock.x - 1) / threadsPerBlock.x, 
                       (N + threadsPerBlock.y - 1) / threadsPerBlock.y);

    // 5. Launch the Kernel
    double start =  omp_get_wtime();
    matrixMulNaive<<<blocksPerGrid, threadsPerBlock>>>(d_A, d_B, d_C, N);
    cudaDeviceSynchronize();
    double gpu_time = omp_get_wtime() - start;
    start =  omp_get_wtime();
    // 6. Copy result back to Host
    cudaMemcpy(h_C, d_C, size, cudaMemcpyDeviceToHost);
    double copy_time = omp_get_wtime() - start;

    // Verify a small piece of the result
    std::cout << "Result at C[0]: " << h_C[0] << " (Expected: " << (float)N * 2.0f << ")" << std::endl;
    std::cout << "Compute time: " << gpu_time << " GFLOPS: " << N*N*N*2/gpu_time/1000000000  << std::endl;
    std::cout << "Copy time: " << copy_time << std::endl;
    // 7. Cleanup
    cudaFree(d_A);
    cudaFree(d_B);
    cudaFree(d_C);
    free(h_A);
    free(h_B);
    free(h_C);

    return 0;
}
