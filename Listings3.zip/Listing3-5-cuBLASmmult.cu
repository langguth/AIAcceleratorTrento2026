#include <iostream>
#include <cuda_runtime.h>
#include <omp.h>
#include <cublas_v2.h>

int main(int argc,char *argv[])
{	
    long N = (argc > 1) ? atol(argv[1]) : 512; // Matrix size (512x512)
  
    size_t size = N * N * sizeof(float);
    // 1. Allocate Host memory (CPU)
    float *h_A = (float*)malloc(size);
    float *h_B = (float*)malloc(size);
    float *h_C = (float*)malloc(size);

    // Initialize matrices with some data
    for (int i = 0; i < N * N; i++) {
        h_A[i] = 1.0f; 
        h_B[i] = 2.0f;
    }

    // 2. Allocate Device memory (GPU)
    float *d_A, *d_B, *d_C;
    cudaMalloc(&d_A, size);
    cudaMalloc(&d_B, size);
    cudaMalloc(&d_C, size);

    // 3. Copy data from Host to Device
    cudaMemcpy(d_A, h_A, size, cudaMemcpyHostToDevice);
    cudaMemcpy(d_B, h_B, size, cudaMemcpyHostToDevice);


    // 4. cuBLAS Setup
    cublasHandle_t handle;
    cublasCreate(&handle);

    const float alpha = 1.0f;
    const float beta = 0.0f;

    // 5. THE CALL: C = A * B
    // Swapping A and B handles the Row-Major vs Column-Major issue.
    // Function: cublasSgemm(handle, transa, transb, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc)
    double start =  omp_get_wtime();
    cublasSgemm(handle, 
                CUBLAS_OP_N, CUBLAS_OP_N, 
                N, N, N, 
                &alpha, 
                d_B, N,   // Matrix B becomes first
                d_A, N,   // Matrix A becomes second
                &beta, 
                d_C, N);
    
    cudaDeviceSynchronize();
    double gpu_time = omp_get_wtime() - start;
    start =  omp_get_wtime();
    cudaMemcpy(h_C, d_C, size, cudaMemcpyDeviceToHost);
    double copy_time = omp_get_wtime() - start;

    std::cout << "cuBLAS Result at C[0]: " << h_C[0] << std::endl;
    std::cout << "Compute time: " << gpu_time << " GFLOPS: " << N*N*N*2/gpu_time/1000000000  << std::endl;
    std::cout << "Copy time: " << copy_time << std::endl;

    // 6. Cleanup
    cublasDestroy(handle);
    cudaFree(d_A); cudaFree(d_B); cudaFree(d_C);
    free(h_A); free(h_B); free(h_C);

    return 0;
}


