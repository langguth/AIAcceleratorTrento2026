#include <stdio.h>
#include <stdlib.h>
#include <omp.h>


int main(int argc,char *argv[])
{
	long n = (argc > 1) ? atol(argv[1]) : 10000000000; 
	
	float* A = (float*)malloc(n * sizeof(float));
	float* B = (float*)malloc(n * sizeof(float));

	double start = omp_get_wtime();
    	for (int i = 0; i < n; i++) {
        	A[i] = i;
        	B[i] = 2;
    	}
	double initialization_time =  omp_get_wtime() - start;


	double cpu_sum = 0.0;
	#pragma acc data copyin(A,B) 
	{
		start = omp_get_wtime();
		#pragma acc parallel loop reduction (+:cpu_sum)
		for(long i = 0; i < n; i++){
			cpu_sum+=A[i]*B[i];
		}
	}
	double cpu_time =  omp_get_wtime() - start;
	printf("gpu sum = %.10f,elements %ld  time %.3f s initialization_time %.3f s  \n",cpu_sum,n,cpu_time,initialization_time);
	free(A);
        free(B);
	return 0;
}
