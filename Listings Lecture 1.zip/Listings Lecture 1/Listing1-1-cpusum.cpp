#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(int argc,char *argv[])
{
	clock_t start, end;
	long steps = (argc > 1) ? atol(argv[1]) : 10000000000; 
	double cpu_sum = 0.0;
	start = clock();
	for(long i = 0; i < steps; i++){
		cpu_sum+=i;
	}
	end = clock();
	double cpu_time = ((double)(end - start)) / CLOCKS_PER_SEC;
	printf("cpu sum = %.10f,steps %ld  time %.3f s\n",cpu_sum,steps,cpu_time);
	return 0;
}
