#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc,char *argv[])
{
	long steps = (argc > 1) ? atol(argv[1]) : 10000000000; 
	double cpu_sum = 0.0;
	double start = omp_get_wtime();
	//#pragma omp parallel for reduction (+:cpu_sum)
	#pragma omp target teams distribute parallel for reduction (+:cpu_sum)
//#include <time.h>
	for(long i = 0; i < steps; i++){
		cpu_sum+=i;
	}
	double cpu_time =  omp_get_wtime() - start;
	printf("gpu sum = %.10f,steps %ld  time %.3f s\n",cpu_sum,steps,cpu_time);
	return 0;
}
