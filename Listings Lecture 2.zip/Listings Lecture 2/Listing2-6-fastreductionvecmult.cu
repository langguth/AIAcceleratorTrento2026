#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <iostream>


#define CHECK_CUDA_ERROR(val) check((val), #val, __FILE__, __LINE__)
void check(cudaError_t err, char const* func, char const* file, int line)
{
    if (err != cudaSuccess)
    {
	std::cout << "CUDA Runtime Error at: " << file << ":" << line
                  << std::endl;
	std::cout << cudaGetErrorString(err) << " " << func << std::endl;
        std::exit(EXIT_FAILURE);
    }
}

__global__ void puregpuvecmul(long n,float* d_A,float* d_B,float* d_C)
{
	long id = blockIdx.x*blockDim.x+threadIdx.x;
	if(id<n)
        	d_C[id] = d_A[id]*d_B[id];
}


__global__ void reduction(long n,int gridsize,float* d_C, double* d_gpu_partial_sum, double* d_gpu_sum)
{
	long id = blockIdx.x*blockDim.x+threadIdx.x;
	double sum = 0.0;
	for(long element = id; element < n; element += gridsize) {
		sum += d_C[element];
	}
 	d_gpu_partial_sum[id]=sum;
	__syncthreads();
	
        if(threadIdx.x==0) {
                d_gpu_sum[blockIdx.x] = 0.0;
                for(int j = 0; j < blockDim.x; j++){
                        d_gpu_sum[blockIdx.x] += d_gpu_partial_sum[ blockIdx.x*blockDim.x+j];
                }
        }

}

__global__ void reductionFinish(int blocks, double* d_final_gpu_sum, double* d_gpu_sum)
{
        for(long i = 0; i < blocks; i++){
                d_final_gpu_sum[0] += d_gpu_sum[i];
        }
}


int main(int argc,char *argv[])
{
	long n = (argc > 1) ? atol(argv[1]) : 10000000000;
	long threads_per_block = (argc > 2) ? atol(argv[2]) : 32;
	double gpu_sum=0.0;

        long threads = (argc > 3) ? atol(argv[2]) : 256;
        long reductionblocks = (argc > 4) ? atol(argv[3]) : 108;

        double* d_final_gpu_sum;
        double* d_gpu_partial_sum;
        double* d_gpu_sum;
        cudaMalloc((void **)&d_gpu_partial_sum,reductionblocks * threads * sizeof(double));
        cudaMalloc((void **)&d_gpu_sum,reductionblocks * sizeof(double));
        cudaMalloc((void **)&d_final_gpu_sum, sizeof(double));


	float* A = (float*)malloc(n * sizeof(float));
        float* B = (float*)malloc(n * sizeof(float));
        float* C = (float*)malloc(n * sizeof(float));
	float* d_A;
	float* d_B;
	float* d_C;
        CHECK_CUDA_ERROR(cudaMalloc((void **)&d_A,n * sizeof(float)));
	CHECK_CUDA_ERROR(cudaMalloc((void **)&d_B,n * sizeof(float)));
	CHECK_CUDA_ERROR(cudaMalloc((void **)&d_C,n * sizeof(float)));

	#pragma omp parallel for
	for (long i = 0; i < n; i++) {
                A[i] = i;
                B[i] = 2;
        }
	int blocks = ceil(n /threads_per_block);
	cudaMemcpy(d_A, A, n * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(d_B, B, n * sizeof(float), cudaMemcpyHostToDevice);
	double start =  omp_get_wtime();

	puregpuvecmul<<<blocks,threads_per_block>>>(n,d_A,d_B,d_C);
	cudaDeviceSynchronize();
        int gridsize = reductionblocks*threads;
	double gpu_time = omp_get_wtime() - start;
        start =  omp_get_wtime();
        reduction<<<reductionblocks,threads>>>(n,gridsize,d_C,d_gpu_partial_sum,d_gpu_sum);
        cudaDeviceSynchronize();
	reductionFinish<<<1,1>>>(reductionblocks,d_final_gpu_sum,d_gpu_sum);
	cudaMemcpy(&gpu_sum, d_final_gpu_sum, sizeof(double), cudaMemcpyDeviceToHost);
	cudaDeviceSynchronize();
        double reducetime = omp_get_wtime() - start;

        printf("gpu sum = %.10f,steps %ld compute time %.4f s reduction time %.5f s \n",gpu_sum,n,gpu_time,reducetime);


	free(A);
	free(B);
	free(C);
	cudaFree(d_A);
	cudaFree(d_B);
	cudaFree(d_C);
	return 0;
}





