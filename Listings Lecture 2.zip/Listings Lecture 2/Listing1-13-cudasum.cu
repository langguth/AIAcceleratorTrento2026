#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>

__global__ void gpusum(long steps,double* d_gpu_sum)
{
	long size = (steps + blockDim.x - 1) / blockDim.x; 
	long start = threadIdx.x*size;
	long end = min(start+size,steps);

	double sum=0.0;
	for(long i = start; i < end; i++){
                sum += i;
        }
	d_gpu_sum[threadIdx.x]=sum;
}

int main(int argc,char *argv[])
{
	long steps = (argc > 1) ? atol(argv[1]) : 10000000000;
	long threads = (argc > 2) ? atol(argv[2]) : 32;
	double* gpu_partial_sum;
	double gpu_sum;
        double* d_gpu_sum;
	gpu_partial_sum = (double *)malloc(threads * sizeof(double));
	cudaMalloc((void **)&d_gpu_sum,threads * sizeof(double));
	double start =  omp_get_wtime();
	gpusum<<<1,threads>>>(steps,d_gpu_sum);
	cudaDeviceSynchronize();
        cudaMemcpy(gpu_partial_sum, d_gpu_sum, threads * sizeof(double), cudaMemcpyDeviceToHost);
	for(int i = 0; i < threads; i++){
       		gpu_sum += gpu_partial_sum[i];
        }
	double gpu_time = omp_get_wtime() - start;
	printf("gpu sum = %.10f,steps %ld  time %.3f s\n",gpu_sum,steps,gpu_time);
	return 0;
}
