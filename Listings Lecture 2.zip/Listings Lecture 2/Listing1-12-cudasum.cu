#include <stdio.h>
#include <stdlib.h>
#include <omp.h>


__global__ void gpusum(long steps,double* d_gpu_sum)
{
	double sum=0.0;
	for(int i = 0; i < steps; i++){
                sum += i;
        }
	d_gpu_sum[0]=sum;
}

int main(int argc,char *argv[])
{
	long steps = (argc > 1) ? atol(argv[1]) : 10000000000;


	double gpu_sum;
        double* d_gpu_sum;
	cudaMalloc((void **)&d_gpu_sum, sizeof(double));

	double start =  omp_get_wtime();

	gpusum<<<1,1>>>(steps,d_gpu_sum);
	cudaDeviceSynchronize(); 
	cudaMemcpy(&gpu_sum, d_gpu_sum, sizeof(double), cudaMemcpyDeviceToHost);
	double gpu_time = omp_get_wtime() - start;
	
	printf("gpu sum = %.10f,steps %ld  time %.3f s\n",gpu_sum,steps,gpu_time);
	return 0;
}
