#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <iostream>


#define CHECK_CUDA_ERROR(val) check((val), #val, __FILE__, __LINE__)
void check(cudaError_t err, char const* func, char const* file, int line)
{
    if (err != cudaSuccess)
    {
	std::cout << "CUDA Runtime Error at: " << file << ":" << line
                  << std::endl;
	std::cout << cudaGetErrorString(err) << " " << func << std::endl;
        std::exit(EXIT_FAILURE);
    }
}

__global__ void gpuvecmul(long n,float* d_A,float* d_B, double* d_gpu_partial_sum, double* d_gpu_sum)
{
	long id = blockIdx.x*blockDim.x+threadIdx.x;
	long totalthreads = blockDim.x * gridDim.x;
	long size = (n + totalthreads - 1) / totalthreads; 
	long start = id*size;
	long end = min(start+size,n);

	double sum=0.0;
	for(long i = start; i < end; i++){
                sum += d_A[i]*d_B[i];
        }
	d_gpu_partial_sum[id]=sum;
        __syncthreads();
        if(threadIdx.x==0) {
                d_gpu_sum[blockIdx.x] = 0.0;
                for(int j = 0; j < blockDim.x; j++){
                        d_gpu_sum[blockIdx.x] += d_gpu_partial_sum[ blockIdx.x*blockDim.x+j];
                }
        }        
}



__global__ void reduction(int blocks, double* d_final_gpu_sum, double* d_gpu_sum)
{
	for(long i = 0; i < blocks; i++){
                d_final_gpu_sum[0] += d_gpu_sum[i];
        }
}

int main(int argc,char *argv[])
{
	long n = (argc > 1) ? atol(argv[1]) : 10000000000;
	long threads = (argc > 2) ? atol(argv[2]) : 32;
	long blocks = (argc > 3) ? atol(argv[3]) : 32;
	double* d_final_gpu_sum;
	double* d_gpu_partial_sum;
	double gpu_sum;
        double* d_gpu_sum;
	cudaMalloc((void **)&d_gpu_partial_sum,blocks * threads * sizeof(double));
	cudaMalloc((void **)&d_gpu_sum,blocks * sizeof(double));
        cudaMalloc((void **)&d_final_gpu_sum, sizeof(double));	

	float* A = (float*)malloc(n * sizeof(float));
        float* B = (float*)malloc(n * sizeof(float));
        float* d_A;
	float* d_B;
        CHECK_CUDA_ERROR(cudaMalloc((void **)&d_A,n * sizeof(float)));
	CHECK_CUDA_ERROR(cudaMalloc((void **)&d_B,n * sizeof(float)));

	#pragma omp parallel for
	for (long i = 0; i < n; i++) {
                A[i] = i;
                B[i] = 2;
        }

	cudaMemcpy(d_A, A, n * sizeof(float), cudaMemcpyHostToDevice);
	cudaMemcpy(d_B, B, n * sizeof(float), cudaMemcpyHostToDevice);
	double start =  omp_get_wtime();

	gpuvecmul<<<blocks,threads>>>(n,d_A,d_B,d_gpu_partial_sum,d_gpu_sum);
	cudaDeviceSynchronize();
        double gpu_time = omp_get_wtime() - start;
        start =  omp_get_wtime();
	reduction<<<1,1>>>(blocks,d_final_gpu_sum,d_gpu_sum);
	cudaDeviceSynchronize();
        cudaMemcpy(&gpu_sum, d_final_gpu_sum, sizeof(double), cudaMemcpyDeviceToHost);

	double reducetime = omp_get_wtime() - start;

        printf("gpu sum = %.10f,steps %ld compute time %.4f s reduction time %.5f s \n",gpu_sum,n,gpu_time,reducetime);
	
	free(A);
	free(B);
	cudaFree(d_A);
	cudaFree(d_B);
	return 0;
}





