#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>

__global__ void gpusum(long steps,double* d_gpu_sum)
{
	long id = blockIdx.x*blockDim.x+threadIdx.x;
	long totalthreads = blockDim.x * gridDim.x;
	long size = (steps + totalthreads - 1) / totalthreads; 
	long start = id*size;
	long end = min(start+size,steps);

	double sum=0.0;
	for(long i = start; i < end; i++){
                sum += i;
        }
	d_gpu_sum[id]=sum;
}

int main(int argc,char *argv[])
{
	long steps = (argc > 1) ? atol(argv[1]) : 10000000000;
	long threads = (argc > 2) ? atol(argv[2]) : 32;
	long blocks = (argc > 3) ? atol(argv[3]) : 32;
	double* gpu_partial_sum;
	double gpu_sum;
        double* d_gpu_sum;
	gpu_partial_sum = (double *)malloc(blocks * threads * sizeof(double));
	cudaMalloc((void **)&d_gpu_sum,blocks * threads * sizeof(double));
	double start =  omp_get_wtime();
	gpusum<<<blocks,threads>>>(steps,d_gpu_sum);
	cudaDeviceSynchronize();
        cudaMemcpy(gpu_partial_sum, d_gpu_sum, blocks * threads * sizeof(double), cudaMemcpyDeviceToHost);
	for(long i = 0; i < blocks*threads; i++){
       		gpu_sum += gpu_partial_sum[i];
        }
	double gpu_time = omp_get_wtime() - start;
	
	printf("gpu sum = %.10f,steps %ld  time %.4f s\n",gpu_sum,steps,gpu_time);
	return 0;
}
