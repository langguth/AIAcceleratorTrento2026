/*
 * cublas_gemm.cu  —  fp16 Tensor Core GEMM via cuBLAS
 *
 * Computes: D = alpha*(A*B) + beta*C   (standard BLAS GEMM form)
 *
 * cuBLAS uses the same Tensor Cores as our hand-written kernel but with
 * architecture-specific auto-tuning, swizzled smem layouts, and warp
 * specialisation — typically reaching 280–305 TFLOPS on A100 fp16.
 *
 * Compile:
 *   nvcc -arch=sm_80 -O3 --use_fast_math -lcublas -o cublas_gemm cublas_gemm.cu
 */

#include <stdio.h>
#include <stdlib.h>
#include <cuda_fp16.h>
#include <cublas_v2.h>

// ─── Matrix dimensions ────────────────────────────────────────────────────────
//#define M 4096
//#define N 4096
//#define K 4096

// ─── Error checking ───────────────────────────────────────────────────────────
static void chk_cuda(cudaError_t e, const char* t) {
    if (e != cudaSuccess) {
        fprintf(stderr, "CUDA error [%s]: %s\n", t, cudaGetErrorString(e));
        exit(1);
    }
}

static void chk_cublas(cublasStatus_t s, const char* t) {
    if (s != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "cuBLAS error [%s]: %d\n", t, (int)s);
        exit(1);
    }
}

int main(int argc, char *argv[])
{
    int M = (argc > 1) ? atoi(argv[1]) : 2048;
    int N = (argc > 2) ? atoi(argv[2]) : 2048;
    int K = (argc > 3) ? atoi(argv[3]) : 2048;
    
    printf("cuBLAS fp16 GEMM: D = A(%dx%d) x B(%dx%d) + C\n\n", M, K, K, N);

    // ── Allocate host memory ─────────────────────────────────────────────────

    size_t szA = (size_t)M * K;
    size_t szB = (size_t)K * N;
    size_t szC = (size_t)M * N;

    __half* hA = (__half*)malloc(szA * sizeof(__half));
    __half* hB = (__half*)malloc(szB * sizeof(__half));
    __half* hC = (__half*)malloc(szC * sizeof(__half));   // cuBLAS gemm_ex takes fp16 C too
    float*  hD = (float* )malloc(szC * sizeof(float));

    srand(42);
    for (size_t i = 0; i < szA; ++i) hA[i] = __float2half((rand() % 9 - 4) * 0.05f);
    for (size_t i = 0; i < szB; ++i) hB[i] = __float2half((rand() % 9 - 4) * 0.05f);
    for (size_t i = 0; i < szC; ++i) hC[i] = __float2half((rand() % 5 - 2) * 0.05f);

    // ── Allocate device memory ───────────────────────────────────────────────
    __half *dA, *dB, *dC;
    float  *dD;
    chk_cuda(cudaMalloc(&dA, szA * sizeof(__half)), "malloc A");
    chk_cuda(cudaMalloc(&dB, szB * sizeof(__half)), "malloc B");
    chk_cuda(cudaMalloc(&dC, szC * sizeof(__half)), "malloc C");
    chk_cuda(cudaMalloc(&dD, szC * sizeof(float)),  "malloc D");

    chk_cuda(cudaMemcpy(dA, hA, szA * sizeof(__half), cudaMemcpyHostToDevice), "H2D A");
    chk_cuda(cudaMemcpy(dB, hB, szB * sizeof(__half), cudaMemcpyHostToDevice), "H2D B");
    chk_cuda(cudaMemcpy(dC, hC, szC * sizeof(__half), cudaMemcpyHostToDevice), "H2D C");

    // ── Create cuBLAS handle ──────────────────────────────────────────────────
    cublasHandle_t handle;
    chk_cublas(cublasCreate(&handle), "create");

    // Tell cuBLAS to use Tensor Cores. Options:
    //   CUBLAS_DEFAULT_MATH             — let cuBLAS decide
    //   CUBLAS_TENSOR_OP_MATH           — force Tensor Cores (deprecated alias)
    //   CUBLAS_MATH_DISALLOW_REDUCED_PRECISION_REDUCTION — fp32 accumulate only
    chk_cublas(cublasSetMathMode(handle, CUBLAS_DEFAULT_MATH), "set math mode");

    // ── Warmup ───────────────────────────────────────────────────────────────
    // IMPORTANT: cuBLAS matrices are column-major by default.
    // To use row-major A and B without transposing them in memory, swap the
    // A/B arguments and set transa/transb to CUBLAS_OP_N.
    //
    // Mathematical equivalence:
    //   Row-major:    D  = A   * B   + C        (A: M×K, B: K×N)
    //   Column-major: D' = B'  * A'  + C'       (swap args, same data)
    //   → pass B as the first matrix arg, A as second, with OP_N on both.
    //
    // This is the standard "swap trick" — no extra transposes needed.
    const float alpha = 1.0f;
    const float beta  = 1.0f;

    // cublasGemmEx gives full control over input/output/compute types.
    // Use CUBLAS_COMPUTE_32F for fp32 accumulation (matches our hand kernel).
    // Use CUBLAS_COMPUTE_16F for pure fp16 (faster, less precise).
    chk_cublas(cublasGemmEx(
        handle,
        CUBLAS_OP_N, CUBLAS_OP_N,   // no transpose
        N, M, K,                     // n, m, k  (note: swapped due to col-major)
        &alpha,
        dB, CUDA_R_16F, N,           // B is first arg in the swap trick
        dA, CUDA_R_16F, K,           // A is second arg
        &beta,
        dD, CUDA_R_32F, N,           // output D in fp32
        CUBLAS_COMPUTE_32F,          // accumulate in fp32 (use 16F for max speed)
        CUBLAS_GEMM_DEFAULT_TENSOR_OP
    ), "gemm warmup");
    cudaDeviceSynchronize();

    // ── Benchmark ─────────────────────────────────────────────────────────────
    cudaEvent_t t0, t1;
    cudaEventCreate(&t0);
    cudaEventCreate(&t1);

    const int REPS = 10;
    cudaEventRecord(t0);
    for (int i = 0; i < REPS; ++i) {
        chk_cublas(cublasGemmEx(
            handle,
            CUBLAS_OP_N, CUBLAS_OP_N,
            N, M, K,
            &alpha,
            dB, CUDA_R_16F, N,
            dA, CUDA_R_16F, K,
            &beta,
            dD, CUDA_R_32F, N,
            CUBLAS_COMPUTE_32F,
            CUBLAS_GEMM_DEFAULT_TENSOR_OP
        ), "gemm bench");
    }
    cudaEventRecord(t1);
    cudaEventSynchronize(t1);

    float ms = 0.f;
    cudaEventElapsedTime(&ms, t0, t1);
    ms /= REPS;

    double flops  = 2.0 * M * N * K;
    double tflops = flops / (ms * 1e-3) / 1e12;
    printf("cuBLAS time:        %.3f ms\n", ms);
    printf("cuBLAS performance: %.1f TFLOPS\n", tflops);
    printf("A100 fp16 TC peak:  312 TFLOPS\n");

    // ── Copy result back (optional verification) ──────────────────────────────
    chk_cuda(cudaMemcpy(hD, dD, szC * sizeof(float), cudaMemcpyDeviceToHost), "D2H D");

    // ── Cleanup ───────────────────────────────────────────────────────────────
    cublasDestroy(handle);
    cudaEventDestroy(t0);
    cudaEventDestroy(t1);
    free(hA); free(hB); free(hC); free(hD);
    cudaFree(dA); cudaFree(dB); cudaFree(dC); cudaFree(dD);
    return 0;
}

/*
 * ─── Quick reference: cublasGemmEx signature ──────────────────────────────────
 *
 *  cublasGemmEx(handle,
 *    transa, transb,          CUBLAS_OP_N (none) or CUBLAS_OP_T (transpose)
 *    m, n, k,                 output rows, output cols, inner dimension
 *    alpha,                   scalar multiplier (pointer to float/half/etc.)
 *    A, Atype, lda,           matrix A pointer, element type, leading dimension
 *    B, Btype, ldb,           matrix B
 *    beta,                    scalar for C
 *    C, Ctype, ldc,           output matrix
 *    computeType,             precision for accumulation
 *    algo)                    CUBLAS_GEMM_DEFAULT_TENSOR_OP or specific algo
 *
 * ─── Compute type options ─────────────────────────────────────────────────────
 *
 *  CUBLAS_COMPUTE_32F          fp32 accumulate — matches our hand-written kernel
 *  CUBLAS_COMPUTE_32F_FAST_16F fp32 acc but allows internal fp16 reductions (faster)
 *  CUBLAS_COMPUTE_16F          fp16 accumulate — fastest, least precise
 *
 * ─── Algorithm selection ──────────────────────────────────────────────────────
 *
 *  CUBLAS_GEMM_DEFAULT_TENSOR_OP   let cuBLAS auto-select (usually best)
 *  CUBLAS_GEMM_ALGO0_TENSOR_OP
 *    through
 *  CUBLAS_GEMM_ALGO15_TENSOR_OP    explicit algorithm index (profile to find best)
 *
 *  To benchmark all algorithms and pick the fastest for your matrix size:
 *
 *    for (int algo = CUBLAS_GEMM_ALGO0_TENSOR_OP;
 *             algo <= CUBLAS_GEMM_ALGO15_TENSOR_OP; ++algo) {
 *        // time cublasGemmEx with (cublasGemmAlgo_t)algo
 *    }
 *
 * ─── Batched GEMM (e.g. for transformers) ────────────────────────────────────
 *
 *  cublasGemmStridedBatchedEx(handle,
 *    transa, transb, m, n, k, alpha,
 *    A, Atype, lda, strideA,   // strideA = M*K for contiguous batch
 *    B, Btype, ldb, strideB,
 *    beta,
 *    C, Ctype, ldc, strideC,
 *    batchCount,
 *    computeType, algo)
 */

