/*
 * Tensor Core Matrix Multiplication using WMMA API
 *
 * Computes: D = A * B + C
 *
 * Requirements:
 *   - GPU with Tensor Cores (Volta/Turing/Ampere+, sm_70+)
 *   - CUDA 9.0+
 *
 * Compile:
 *   nvcc -arch=sm_80 -o tensor_core_matmul tensor_core_matmul.cu
 *
 * Matrix dimensions must be multiples of 16 for WMMA 16x16x16 tiles.
 */

#include <stdio.h>
#include <stdlib.h>
#include <cuda_fp16.h>
#include <mma.h>

using namespace nvcuda;

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

// WMMA tile size (fixed by the API for fp16 with 16x16x16 shape)
#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16

// Thread-block tile dimensions (in units of WMMA tiles)
#define BLOCK_TILE_M 2   // Each block computes a (2*16) x (2*16) output tile
#define BLOCK_TILE_N 2

// ---------------------------------------------------------------------------
// Kernel
// ---------------------------------------------------------------------------
__global__ void wmma_matmul_kernel(
    const __half* __restrict__ A,   // [M x K], row-major
    const __half* __restrict__ B,   // [K x N], row-major
    const float*  __restrict__ C,   // [M x N], row-major (accumulator bias)
          float*              D,    // [M x N], row-major (output)
    int m, int n, int k)
{
    // Each warp is responsible for one WMMA_M x WMMA_N output sub-tile.
    // We map: blockIdx -> a (BLOCK_TILE_M * WMMA_M) x (BLOCK_TILE_N * WMMA_N) region
    //         warpIdx  -> one WMMA_M x WMMA_N tile within that region

    const int warpId   = (threadIdx.x / 32);
    const int warpRow  = warpId / BLOCK_TILE_N;   // warp row within the block tile
    const int warpCol  = warpId % BLOCK_TILE_N;   // warp col within the block tile

    // Global row / col for the top-left corner of this warp's output tile
    const int row = (blockIdx.y * BLOCK_TILE_M + warpRow) * WMMA_M;
    const int col = (blockIdx.x * BLOCK_TILE_N + warpCol) * WMMA_N;

    if (row >= m || col >= n) return;

    // Declare WMMA fragments
    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float>                acc_frag;

    // Load the C tile into the accumulator (bias / initial value)
    wmma::load_matrix_sync(acc_frag, C + row * n + col, n, wmma::mem_row_major);

    // Tile over the K dimension
    for (int ki = 0; ki < k; ki += WMMA_K) {
        wmma::load_matrix_sync(a_frag, A + row * k + ki,     k);   // A[row..row+16, ki..ki+16]
        wmma::load_matrix_sync(b_frag, B + ki  * n + col,    n);   // B[ki..ki+16, col..col+16]

        // Tensor Core MMA: acc += a * b
        wmma::mma_sync(acc_frag, a_frag, b_frag, acc_frag);
    }

    // Store result to D
    wmma::store_matrix_sync(D + row * n + col, acc_frag, n, wmma::mem_row_major);
}

// ---------------------------------------------------------------------------
// CPU reference (fp32)
// ---------------------------------------------------------------------------
void cpu_matmul(const float* A, const float* B, const float* C,
                float* D, int m, int n, int k)
{
    for (int i = 0; i < m; ++i)
        for (int j = 0; j < n; ++j) {
            float acc = C[i * n + j];
            for (int l = 0; l < k; ++l)
                acc += A[i * k + l] * B[l * n + j];
            D[i * n + j] = acc;
        }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
static void checkCuda(cudaError_t err, const char* msg) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error at %s: %s\n", msg, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

// Compare two fp32 matrices; return max absolute error
float max_abs_error(const float* ref, const float* test, int n) {
    float maxErr = 0.f;
    for (int i = 0; i < n; ++i) {
        float e = fabsf(ref[i] - test[i]);
        if (e > maxErr) maxErr = e;
    }
    return maxErr;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    int M = (argc > 1) ? atoi(argv[1]) : 256;
    int N = (argc > 2) ? atoi(argv[2]) : 256;
    int K = (argc > 3) ? atoi(argv[3]) : 256;
    printf("Tensor Core WMMA demo: D = A(%dx%d) * B(%dx%d) + C\n\n", M, K, K, N);

    // ---- Allocate host memory ----
    size_t sizeA  = (size_t)M * K;
    size_t sizeB  = (size_t)K * N;
    size_t sizeCD = (size_t)M * N;

    float*  h_A_fp32 = (float*)malloc(sizeA  * sizeof(float));
    float*  h_B_fp32 = (float*)malloc(sizeB  * sizeof(float));
    float*  h_C      = (float*)malloc(sizeCD * sizeof(float));
    float*  h_D_gpu  = (float*)malloc(sizeCD * sizeof(float));
    float*  h_D_cpu  = (float*)malloc(sizeCD * sizeof(float));
    __half* h_A_fp16 = (__half*)malloc(sizeA  * sizeof(__half));
    __half* h_B_fp16 = (__half*)malloc(sizeB  * sizeof(__half));

    // ---- Initialize with random data ----
    srand(42);
    for (size_t i = 0; i < sizeA;  ++i) { h_A_fp32[i] = (rand() % 9 - 4) * 0.1f; h_A_fp16[i] = __float2half(h_A_fp32[i]); }
    for (size_t i = 0; i < sizeB;  ++i) { h_B_fp32[i] = (rand() % 9 - 4) * 0.1f; h_B_fp16[i] = __float2half(h_B_fp32[i]); }
    for (size_t i = 0; i < sizeCD; ++i)   h_C[i]      = (rand() % 5 - 2) * 0.1f;

    // ---- Allocate & copy to device ----
    __half *d_A, *d_B;
    float  *d_C, *d_D;
    checkCuda(cudaMalloc(&d_A, sizeA  * sizeof(__half)), "malloc A");
    checkCuda(cudaMalloc(&d_B, sizeB  * sizeof(__half)), "malloc B");
    checkCuda(cudaMalloc(&d_C, sizeCD * sizeof(float)),  "malloc C");
    checkCuda(cudaMalloc(&d_D, sizeCD * sizeof(float)),  "malloc D");

    checkCuda(cudaMemcpy(d_A, h_A_fp16, sizeA  * sizeof(__half), cudaMemcpyHostToDevice), "copy A");
    checkCuda(cudaMemcpy(d_B, h_B_fp16, sizeB  * sizeof(__half), cudaMemcpyHostToDevice), "copy B");
    checkCuda(cudaMemcpy(d_C, h_C,      sizeCD * sizeof(float),  cudaMemcpyHostToDevice), "copy C");

    // ---- Launch kernel ----
    // Grid: each block covers (BLOCK_TILE_M*WMMA_M) rows x (BLOCK_TILE_N*WMMA_N) cols
    // Block: BLOCK_TILE_M * BLOCK_TILE_N warps  =>  * 32 threads
    dim3 blockDim(BLOCK_TILE_M * BLOCK_TILE_N * 32);
    dim3 gridDim(
        (N + BLOCK_TILE_N * WMMA_N - 1) / (BLOCK_TILE_N * WMMA_N),
        (M + BLOCK_TILE_M * WMMA_M - 1) / (BLOCK_TILE_M * WMMA_M)
    );

    printf("Grid:  (%u, %u)\n", gridDim.x, gridDim.y);
    printf("Block: %u threads (%d warps)\n\n", blockDim.x, BLOCK_TILE_M * BLOCK_TILE_N);

    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);
    cudaEventRecord(start);

    wmma_matmul_kernel<<<gridDim, blockDim>>>(d_A, d_B, d_C, d_D, M, N, K);

    cudaEventRecord(stop);
    cudaEventSynchronize(stop);
    checkCuda(cudaGetLastError(), "kernel launch");

    float ms = 0.f;
    cudaEventElapsedTime(&ms, start, stop);

    // ---- Copy result back ----
    checkCuda(cudaMemcpy(h_D_gpu, d_D, sizeCD * sizeof(float), cudaMemcpyDeviceToHost), "copy D back");

    // ---- CPU reference ----
//    cpu_matmul(h_A_fp32, h_B_fp32, h_C, h_D_cpu, M, N, K);

    // ---- Verify ----
    float err = max_abs_error(h_D_cpu, h_D_gpu, (int)sizeCD);
    printf("Max absolute error vs CPU (fp32): %.6f\n", err);
    printf("  (small errors expected due to fp16 inputs)\n\n");

    // Compute TFLOPS  (2*M*N*K flops for matmul)
    double flops   = 2.0 * M * N * K;
    double tflops  = flops / (ms * 1e-3) / 1e12;
    printf("Kernel time : %.3f ms\n", ms);
    printf("Performance : %.2f TFLOPS\n", tflops);

    // ---- Cleanup ----
    free(h_A_fp32); free(h_B_fp32); free(h_C);
    free(h_D_gpu);  free(h_D_cpu);
    free(h_A_fp16); free(h_B_fp16);
    cudaFree(d_A); cudaFree(d_B); cudaFree(d_C); cudaFree(d_D);
    cudaEventDestroy(start); cudaEventDestroy(stop);

    return 0;
}

