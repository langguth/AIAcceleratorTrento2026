#include <iostream>
#include <cuda_runtime.h>
#include <omp.h>
#define dt 0.1

__global__ void stencilkernel(double* gridold, double* gridnew, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row > 0 && col > 0 && row < N-1 && col < N-1) {
	double change = gridold[(row-1)*N+col]+gridold[row*N+col-1]+gridold[(row+1)*N+col]+gridold[row*N+col+1]-4.0*gridold[row*N+col];
	gridnew[row * N + col] = gridold[row * N + col] + dt * change;
   }
}

int main(int argc,char *argv[])
{	
    long N = (argc > 1) ? atol(argv[1]) : 512; // Actual grid size (510x510)
    int threads = (argc > 2) ? atol(argv[2]) : 16;  
    int iterations = (argc > 3) ? atol(argv[3]) : 100;
  
    size_t size = N * N * sizeof(double);
    // 1. Allocate Host memory (CPU)
    double *h_grid = (double*)malloc(size);
    
    // Initialize grid with some data
    for (int i = 0; i < N * N; i++) {
        h_grid[i] = 0.0f; 
    }
    h_grid[N+1]=1;//Initialize some value

    // 2. Allocate Device memory (GPU)
    double *d_gridold, *d_gridnew, *d_gridtemp;
    cudaMalloc(&d_gridold, size);
    cudaMalloc(&d_gridnew, size);

    // 3. Copy data from Host to Device
    cudaMemcpy(d_gridold, h_grid, size, cudaMemcpyHostToDevice);

    // 4. Define Launch Parameters
    dim3 threadsPerBlock(threads, threads);
    dim3 blocksPerGrid((N + threadsPerBlock.x - 1) / threadsPerBlock.x, 
                       (N + threadsPerBlock.y - 1) / threadsPerBlock.y);

    double start =  omp_get_wtime();
    for (int i = 0; i < iterations; i++) {
      stencilkernel<<<blocksPerGrid, threadsPerBlock>>>(d_gridold, d_gridnew,  N);

      //Pointer Swap
      d_gridtemp = d_gridold;
      d_gridold = d_gridnew;
      d_gridnew = d_gridtemp;
    }
      

    cudaDeviceSynchronize();
    double gpu_time = omp_get_wtime() - start;
    start =  omp_get_wtime();
    // 6. Copy result back to Host
    cudaMemcpy(h_grid, d_gridold, size, cudaMemcpyDeviceToHost);
    double copy_time = omp_get_wtime() - start;

    // Verify a small piece of the result
    std::cout << "Result at top left: " << h_grid[N+1] << std::endl;
    std::cout << "Result at bottom right: " << h_grid[N*(N-1)-2] << std::endl;
    std::cout << "Compute time: " << gpu_time << std::endl;
    std::cout << "Copy time: " << copy_time << std::endl;
    // 7. Cleanup
    cudaFree(d_gridold);
    cudaFree(d_gridnew);
    free(h_grid);

    return 0;
}
