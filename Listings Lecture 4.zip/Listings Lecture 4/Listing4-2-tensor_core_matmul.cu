/*
 * Optimized Tensor Core Matrix Multiplication — D = A * B + C
 *
 * Problem with the naive version when M/N/K are large:
 *   Every warp reads A and B directly from global memory (high latency, ~GB/s).
 *   Neighbouring warps re-read the same rows/columns with zero reuse.
 *
 * Optimizations applied here:
 *   1. Shared memory tiling      – All warps in a block cooperatively load one
 *                                  BLOCK_M x BLOCK_K tile of A and BLOCK_K x BLOCK_N
 *                                  tile of B into fast shared memory (~10 TB/s),
 *                                  then each warp reads its fragment from there.
 *   2. Larger block tile (4x4)   – 16 warps / 512 threads per block vs 4 warps / 128.
 *                                  More threads = faster smem fill, better occupancy.
 *   3. Multi-step K per smem tile – BLOCK_K=32 covers 2 WMMA_K steps before reloading,
 *                                  halving the number of global→smem round-trips.
 *   4. Shared memory padding      – +8 fp16 per row shifts bank access patterns and
 *                                  eliminates most bank conflicts for fp16 data.
 *   5. float2 vectorized loads    – Each thread loads 4 fp16 (1 float2) per store,
 *                                  doubling memory transaction width.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cuda_fp16.h>
#include <mma.h>

using namespace nvcuda;


// ---------------------------------------------------------------------------
// WMMA tile size (fixed by the fp16 API)
// ---------------------------------------------------------------------------
#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16

// ---------------------------------------------------------------------------
// Block configuration — optimized kernel
// ---------------------------------------------------------------------------
#define WARP_ROWS        4                            // warps tiled in M direction
#define WARP_COLS        4                            // warps tiled in N direction
#define WARPS_PER_BLOCK  (WARP_ROWS * WARP_COLS)     // 16 warps
#define THREADS_PER_BLOCK (WARPS_PER_BLOCK * 32)     // 512 threads

#define BLOCK_M  (WARP_ROWS * WMMA_M)   //  64  rows  covered by one block
#define BLOCK_N  (WARP_COLS * WMMA_N)   //  64  cols  covered by one block
#define BLOCK_K  32                      //  K   slice loaded into shared mem (2 × WMMA_K)

// Padding: fp16 = 2 bytes; one CUDA shared-mem bank = 4 bytes (holds 2 fp16).
// 32 banks × 4 bytes = 128 bytes per "row of banks".
// Adding 8 fp16 (= 16 bytes) per row shifts each thread's column by 4 banks,
// breaking the stride-32 conflict pattern that arises with BLOCK_K / BLOCK_N = 32/64.
#define PAD_A 8
#define PAD_B 8

// ---------------------------------------------------------------------------
// Naive kernel (original design — for timing comparison)
// ---------------------------------------------------------------------------
__global__ void wmma_naive(
    const __half* __restrict__ A,
    const __half* __restrict__ B,
    const float*  __restrict__ C,
          float*              D,
    int m, int n, int k)
{
    // 2×2 warps per block, each warp → one 16×16 output tile
    const int warpId  = threadIdx.x / 32;
    const int warpRow = warpId / 2;
    const int warpCol = warpId % 2;

    const int row = (blockIdx.y * 2 + warpRow) * WMMA_M;
    const int col = (blockIdx.x * 2 + warpCol) * WMMA_N;
    if (row >= m || col >= n) return;

    wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> a_frag;
    wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> b_frag;
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> acc_frag;

    wmma::load_matrix_sync(acc_frag, C + row * n + col, n, wmma::mem_row_major);

    for (int ki = 0; ki < k; ki += WMMA_K) {
        // !! Every iteration: two global memory reads per warp — no reuse !!
        wmma::load_matrix_sync(a_frag, A + row * k + ki, k);
        wmma::load_matrix_sync(b_frag, B + ki  * n + col, n);
        wmma::mma_sync(acc_frag, a_frag, b_frag, acc_frag);
    }

    wmma::store_matrix_sync(D + row * n + col, acc_frag, n, wmma::mem_row_major);
}

// ---------------------------------------------------------------------------
// Optimized kernel
// ---------------------------------------------------------------------------
__global__ void wmma_optimized(
    const __half* __restrict__ A,
    const __half* __restrict__ B,
    const float*  __restrict__ C,
          float*              D,
    int m, int n, int k)
{
    // ---- Shared memory tiles (padded) -----------------------------------
    // smem_A: [64][40] fp16 = 5120 bytes
    // smem_B: [32][72] fp16 = 4608 bytes   total ≈ 9.5 KB
    __shared__ __half smem_A[BLOCK_M][BLOCK_K + PAD_A];
    __shared__ __half smem_B[BLOCK_K][BLOCK_N + PAD_B];

    const int tid     = threadIdx.x;
    const int warpId  = tid / 32;
    const int warpRow = warpId / WARP_COLS;   // 0 .. WARP_ROWS-1
    const int warpCol = warpId % WARP_COLS;   // 0 .. WARP_COLS-1

    // Global position of this warp's output tile
    const int outRow = blockIdx.y * BLOCK_M + warpRow * WMMA_M;
    const int outCol = blockIdx.x * BLOCK_N + warpCol * WMMA_N;

    if (outRow >= m || outCol >= n) return;

    // ---- Load initial accumulator from C --------------------------------
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> acc_frag;
    wmma::load_matrix_sync(acc_frag, C + outRow * n + outCol, n, wmma::mem_row_major);

    // Top-left global corner of this block's A and B tiles
    const int blockRowA = blockIdx.y * BLOCK_M;
    const int blockColB = blockIdx.x * BLOCK_N;

    // ---- Outer loop: stride over K in BLOCK_K steps --------------------
    for (int ki = 0; ki < k; ki += BLOCK_K) {

        // == Cooperative load: smem_A = A[blockRowA : +BLOCK_M, ki : +BLOCK_K] ==
        // BLOCK_M * BLOCK_K = 2048 fp16; load as float2 (4 fp16) per thread.
        // 512 threads × 4 fp16 = 2048 → exactly one pass.
        {
            const int total_f2 = (BLOCK_M * BLOCK_K) / 4;   // 512 float2 groups
            if (tid < total_f2) {
                // Which fp16 elements does this thread own?  base = tid*4 in the
                // flat [BLOCK_M][BLOCK_K] layout (ignoring padding).
                const int flat_base = tid * 4;
                const int r  = flat_base / BLOCK_K;   // smem row (no padding here)
                const int c  = flat_base % BLOCK_K;   // smem col

                const int gRow = blockRowA + r;
                const int gCol = ki + c;

                if (gRow < m && gCol + 3 < k) {
                    // All 4 elements in-bounds: one vectorized float2 load
                    const float2 v = *reinterpret_cast<const float2*>(&A[gRow * k + gCol]);
                    *reinterpret_cast<float2*>(&smem_A[r][c]) = v;
                } else {
                    // Near-boundary: scalar with bounds check
                    #pragma unroll
                    for (int i = 0; i < 4; ++i)
                        smem_A[r][c + i] = (gRow < m && (gCol + i) < k)
                                           ? A[gRow * k + gCol + i]
                                           : __float2half(0.f);
                }
            }
        }

        // == Cooperative load: smem_B = B[ki : +BLOCK_K, blockColB : +BLOCK_N] ==
        // BLOCK_K * BLOCK_N = 2048 fp16; same float2 strategy.
        {
            const int total_f2 = (BLOCK_K * BLOCK_N) / 4;   // 512
            if (tid < total_f2) {
                const int flat_base = tid * 4;
                const int r  = flat_base / BLOCK_N;
                const int c  = flat_base % BLOCK_N;

                const int gRow = ki + r;
                const int gCol = blockColB + c;

                if (gRow < k && gCol + 3 < n) {
                    const float2 v = *reinterpret_cast<const float2*>(&B[gRow * n + gCol]);
                    *reinterpret_cast<float2*>(&smem_B[r][c]) = v;
                } else {
                    #pragma unroll
                    for (int i = 0; i < 4; ++i)
                        smem_B[r][c + i] = (gRow < k && (gCol + i) < n)
                                           ? B[gRow * n + gCol + i]
                                           : __float2half(0.f);
                }
            }
        }

        __syncthreads();

        // == WMMA inner loop: step over BLOCK_K in WMMA_K chunks ===========
        // BLOCK_K / WMMA_K = 2 MMA operations per smem tile — both read from smem.
        wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> a_frag;
        wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> b_frag;

        #pragma unroll
        for (int ki2 = 0; ki2 < BLOCK_K; ki2 += WMMA_K) {
            // A fragment row  = warpRow × WMMA_M  (offset into smem_A)
            // B fragment col  = warpCol × WMMA_N  (offset into smem_B)
            wmma::load_matrix_sync(a_frag,
                                   &smem_A[warpRow * WMMA_M][ki2],
                                   BLOCK_K + PAD_A);
            wmma::load_matrix_sync(b_frag,
                                   &smem_B[ki2][warpCol * WMMA_N],
                                   BLOCK_N + PAD_B);
            wmma::mma_sync(acc_frag, a_frag, b_frag, acc_frag);
        }

        __syncthreads();   // protect smem before next tile load
    }

    // ---- Store result ---------------------------------------------------
    wmma::store_matrix_sync(D + outRow * n + outCol, acc_frag, n, wmma::mem_row_major);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
static void checkCuda(cudaError_t err, const char* tag) {
    if (err != cudaSuccess) {
        fprintf(stderr, "CUDA error [%s]: %s\n", tag, cudaGetErrorString(err));
        exit(EXIT_FAILURE);
    }
}

static float run_kernel(bool optimized,
                        const __half* d_A, const __half* d_B,
                        const float*  d_C, float* d_D,
                        int m, int n, int k, int reps)
{
    cudaEvent_t t0, t1;
    cudaEventCreate(&t0); cudaEventCreate(&t1);

    if (optimized) {
        dim3 block(THREADS_PER_BLOCK);
        dim3 grid(
            (n + BLOCK_N - 1) / BLOCK_N,
            (m + BLOCK_M - 1) / BLOCK_M
        );
        // Warmup
        wmma_optimized<<<grid, block>>>(d_A, d_B, d_C, d_D, m, n, k);
        cudaDeviceSynchronize();
        cudaEventRecord(t0);
        for (int i = 0; i < reps; ++i)
            wmma_optimized<<<grid, block>>>(d_A, d_B, d_C, d_D, m, n, k);
    } else {
        dim3 block(4 * 32);   // 2×2 warps
        dim3 grid(
            (n + 2 * WMMA_N - 1) / (2 * WMMA_N),
            (m + 2 * WMMA_M - 1) / (2 * WMMA_M)
        );
        wmma_naive<<<grid, block>>>(d_A, d_B, d_C, d_D, m, n, k);
        cudaDeviceSynchronize();
        cudaEventRecord(t0);
        for (int i = 0; i < reps; ++i)
            wmma_naive<<<grid, block>>>(d_A, d_B, d_C, d_D, m, n, k);
    }

    cudaEventRecord(t1);
    cudaEventSynchronize(t1);
    checkCuda(cudaGetLastError(), "kernel");

    float ms = 0.f;
    cudaEventElapsedTime(&ms, t0, t1);
    cudaEventDestroy(t0); cudaEventDestroy(t1);
    return ms / reps;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    int m = (argc > 1) ? atoi(argv[1]) : 2048;
    int n = (argc > 2) ? atoi(argv[2]) : 2048;
    int k = (argc > 3) ? atoi(argv[3]) : 2048;
    printf("D = A(%dx%d) * B(%dx%d) + C\n\n", m, k, k, n);

    // --- Host allocation & init ---
    size_t szA  = (size_t)m * k;
    size_t szB  = (size_t)k * n;
    size_t szCD = (size_t)m * n;

    __half* h_A = (__half*)malloc(szA  * sizeof(__half));
    __half* h_B = (__half*)malloc(szB  * sizeof(__half));
    float*  h_C = (float*) malloc(szCD * sizeof(float));

    srand(123);
    for (size_t i = 0; i < szA;  ++i) h_A[i] = __float2half((rand() % 9 - 4) * 0.05f);
    for (size_t i = 0; i < szB;  ++i) h_B[i] = __float2half((rand() % 9 - 4) * 0.05f);
    for (size_t i = 0; i < szCD; ++i) h_C[i]  = (rand() % 5 - 2) * 0.05f;

    // --- Device allocation ---
    __half *d_A, *d_B;
    float  *d_C, *d_D;
    checkCuda(cudaMalloc(&d_A, szA  * sizeof(__half)), "malloc A");
    checkCuda(cudaMalloc(&d_B, szB  * sizeof(__half)), "malloc B");
    checkCuda(cudaMalloc(&d_C, szCD * sizeof(float)),  "malloc C");
    checkCuda(cudaMalloc(&d_D, szCD * sizeof(float)),  "malloc D");

    checkCuda(cudaMemcpy(d_A, h_A, szA  * sizeof(__half), cudaMemcpyHostToDevice), "H2D A");
    checkCuda(cudaMemcpy(d_B, h_B, szB  * sizeof(__half), cudaMemcpyHostToDevice), "H2D B");
    checkCuda(cudaMemcpy(d_C, h_C, szCD * sizeof(float),  cudaMemcpyHostToDevice), "H2D C");

    // --- Time both kernels ---
    const int REPS = 5;
    double flops = 2.0 * m * n * k;

    printf("Running naive   kernel (%d reps)...\n", REPS);
    float ms_naive = run_kernel(false, d_A, d_B, d_C, d_D, m, n, k, REPS);
    printf("  %.3f ms   →  %.2f TFLOPS\n\n", ms_naive, flops / (ms_naive * 1e-3) / 1e12);

    printf("Running optimized kernel (%d reps)...\n", REPS);
    float ms_opt = run_kernel(true, d_A, d_B, d_C, d_D, m, n, k, REPS);
    printf("  %.3f ms   →  %.2f TFLOPS\n\n", ms_opt, flops / (ms_opt   * 1e-3) / 1e12);

    printf("Speedup: %.2fx\n", ms_naive / ms_opt);

    // --- Cleanup ---
    free(h_A); free(h_B); free(h_C);
    cudaFree(d_A); cudaFree(d_B); cudaFree(d_C); cudaFree(d_D);
    return 0;
}

