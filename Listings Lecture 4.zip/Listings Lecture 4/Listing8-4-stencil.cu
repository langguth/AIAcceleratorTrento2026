#include <iostream>
#include <cuda_runtime.h>
#include <omp.h>

#define dt 0.1

// Updated kernel with Neumann BC logic (clamping edges)
__global__ void stencilkernel(double* gridold, double* gridnew, int N, int rows_per_gpu, int gpu_id) {
    int r = blockIdx.y * blockDim.y + threadIdx.y;
    int c = blockIdx.x * blockDim.x + threadIdx.x;

    if (r < rows_per_gpu && c < N) {
        int center = r * N + c;

        // Neighbor indexing with Neumann BCs
        // Vertical neighbors: Clamp to local memory bounds
        int up    = (r > 0) ? (r - 1) * N + c : center;
        int down  = (r < rows_per_gpu - 1) ? (r + 1) * N + c : center;
        
        // Horizontal neighbors: Standard clamping
        int left  = (c > 0) ? r * N + (c - 1) : center;
        int right = (c < N - 1) ? r * N + (c + 1) : center;

        double change = gridold[up] + gridold[down] + gridold[left] + gridold[right] - 4.0 * gridold[center];
        gridnew[center] = gridold[center] + dt * change;
    }
}



int main(int argc, char *argv[]) {
    long N = (argc > 1) ? atol(argv[1]) : 512;
    int threads = (argc > 2) ? atol(argv[2]) : 16;
    int iterations = (argc > 3) ? atol(argv[3]) : 100;

    int num_gpus;
    cudaGetDeviceCount(&num_gpus);
    if (num_gpus < 2) {
        std::cerr << "This code requires at least 2 GPUs." << std::endl;
        return 1;
    }

    int rows_per_gpu = N / 2;
    size_t half_size = rows_per_gpu * N * sizeof(double);
    double *h_grid = (double*)malloc(N * N * sizeof(double));

    // Initialize
    for (int i = 0; i < N * N; i++) h_grid[i] = 0.0;
    h_grid[N + 1] = 1.0; 

    double *d_gridold[2], *d_gridnew[2];

    #pragma omp parallel num_threads(2)
    {
        int tid = omp_get_thread_num();
        cudaSetDevice(tid);

	cudaDeviceEnablePeerAccess (tid, 0);

        // Allocate memory for half the grid
        cudaMalloc(&d_gridold[tid], half_size);
        cudaMalloc(&d_gridnew[tid], half_size);

        // Copy initial data to each GPU
        cudaMemcpy(d_gridold[tid], h_grid + (tid * rows_per_gpu * N), half_size, cudaMemcpyHostToDevice);

        dim3 threadsPerBlock(threads, threads);
        dim3 blocksPerGrid((N + threads - 1) / threads, (rows_per_gpu + threads - 1) / threads);

	double comptime = 0.0;
	double commtime = 0.0;
        #pragma omp barrier // Ensure both GPUs are ready
        for (int i = 0; i < iterations; i++) {
	    double start = omp_get_wtime();
            stencilkernel<<<blocksPerGrid, threadsPerBlock>>>(d_gridold[tid], d_gridnew[tid], N, rows_per_gpu, tid);
            comptime += omp_get_wtime()-start;


            // Pointer Swap
            double* temp = d_gridold[tid];
            d_gridold[tid] = d_gridnew[tid];
            d_gridnew[tid] = temp;

            // HALO EXCHANGE: Only swap the boundary rows
            // GPU 0 sends its bottom row to GPU 1's top-ish region, etc.
            #pragma omp barrier 
	    double cstart = omp_get_wtime();
            if (tid == 0) {
                // GPU 0 gets GPU 1's top row to use as its "down" boundary
		//cudaMemcpy(d_gridold[0] + (rows_per_gpu - 1) * N, d_gridold[1], N * sizeof(double), cudaMemcpyDeviceToDevice);
            } else {
                // GPU 1 gets GPU 0's bottom row to use as its "up" boundary
               //  cudaMemcpy(d_gridold[1],d_gridold[0] + (rows_per_gpu - 1) * N , N * sizeof(double), cudaMemcpyDeviceToDevice);
            }
            #pragma omp barrier
	    commtime += omp_get_wtime()-cstart;
        }

        // Copy back to host
        cudaMemcpy(h_grid + (tid * rows_per_gpu * N), d_gridold[tid], half_size, cudaMemcpyDeviceToHost);
        
        cudaFree(d_gridold[tid]);
        cudaFree(d_gridnew[tid]);
	std::cout << "GPU: " << tid << " Computation time: " << comptime << " Communication time: " << commtime << std::endl;
    }

    std::cout << "Final result at hot spot: " << h_grid[N + 1] << std::endl;
    free(h_grid);
    return 0;
}
