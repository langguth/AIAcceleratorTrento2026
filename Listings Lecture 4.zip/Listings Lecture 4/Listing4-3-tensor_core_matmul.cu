/*
 * Fixes applied in this version
 * ──────────────────────────────────────────────────────────────────────
 * [1] Register tiling — each warp computes a 4×4 grid of WMMA tiles
 *     (64×64 output, 16 accumulators). The 16 MMAs are all independent
 *     so the warp scheduler fills tensor cores while waiting on loads.
 *
 * [2] cp.async double buffering (Ampere+)
 *     Issue global→smem DMA for tile K+1 BEFORE computing tile K.
 *     The A100's dedicated async copy engine runs in parallel with
 *     tensor core activity. The blocking sync is replaced by the
 *     lightweight cp.async.wait_group hardware barrier.
 *
 * [3] Larger tiles — 128×128 block output, BLOCK_K=32
 *     Arithmetic intensity ≈ 64 ops/byte (smem). A100 smem bandwidth
 *     ~10 TB/s → smem ceiling ≈ 640 TFLOPS, so we're compute-bound.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <cuda_fp16.h>
#include <mma.h>

using namespace nvcuda;

// ─── Matrix dimensions ───────────────────────────────────────────────────────
#define MAT_M 4096
#define MAT_N 4096
#define MAT_K 4096

// ─── Fixed WMMA tile (fp16 API) ───────────────────────────────────────────────
#define WMMA_M 16
#define WMMA_N 16
#define WMMA_K 16

// ─── Block tile ───────────────────────────────────────────────────────────────
// Each thread-block covers a 128×128 output region.
// BLOCK_K=32 means 2 WMMA_K steps per smem reload — doubles reuse vs BLOCK_K=16.
#define BLOCK_M   128
#define BLOCK_N   128
#define BLOCK_K    32

// ─── Warp tile ────────────────────────────────────────────────────────────────
// Each warp computes WARP_M×WARP_N WMMA tiles → 64×64 output region.
// 4 warps in a 2×2 arrangement cover the 128×128 block.
// KEY: 16 independent MMA operations per warp keep the scheduler busy.
#define WARP_M      4   // WMMA tiles per warp in M direction (4×16 = 64 rows)
#define WARP_N      4   // WMMA tiles per warp in N direction (4×16 = 64 cols)
#define WARP_ROWS   2   // (BLOCK_M / (WARP_M * WMMA_M)) = 128/64
#define WARP_COLS   2   // (BLOCK_N / (WARP_N * WMMA_N)) = 128/64
#define N_WARPS     4   // WARP_ROWS * WARP_COLS
#define BLOCK_THR   128 // N_WARPS * 32

// ─── Shared memory padding ────────────────────────────────────────────────────
// +8 fp16 per row shifts adjacent-row accesses by 4 banks, breaking the common
// stride-32 conflict pattern. Does not eliminate all conflicts (swizzle does).
#define PAD 8

// ─── Double-buffer stages ─────────────────────────────────────────────────────
#define STAGES 2

// ─── cp.async helpers (sm_80+) ────────────────────────────────────────────────

// Asynchronously copy 16 bytes (8 fp16) from global to shared memory.
// Both pointers must be 16-byte aligned. cudaMalloc guarantees 256-byte base
// alignment; rows are 16-byte aligned when K is a multiple of 8 (true here).
__device__ __forceinline__
void cp_async16(void* smem, const void* gmem) {
    unsigned dst = __cvta_generic_to_shared(smem);
    asm volatile(
        "cp.async.cg.shared.global [%0], [%1], 16;\n"
        :: "r"(dst), "l"(gmem));
}

// Commit all preceding cp.async calls into a new tracked group.
__device__ __forceinline__ void cp_async_commit() {
    asm volatile("cp.async.commit_group;\n");
}

// Wait until at most REMAIN groups are still in flight.
//   wait<1> = "all groups except the most-recently committed one are complete"
//   wait<0> = "all groups are complete"
template<int REMAIN>
__device__ __forceinline__ void cp_async_wait() {
    asm volatile("cp.async.wait_group %0;\n" :: "n"(REMAIN) : "memory");
}

// ─────────────────────────────────────────────────────────────────────────────
// Pipelined kernel
// ─────────────────────────────────────────────────────────────────────────────
__global__ __launch_bounds__(BLOCK_THR, 2)
void gemm_pipelined(
    const __half* __restrict__ A,   // [M×K], fp16, row-major
    const __half* __restrict__ B,   // [K×N], fp16, row-major
    const float*  __restrict__ C,   // [M×N], fp32, bias (β=1 term)
          float*              D,    // [M×N], fp32, output
    int M, int N, int K)
{
    // ── Shared memory ────────────────────────────────────────────────────────
    // Double-buffered tiles (2 stages).
    //   smem_A: 2 × [128][40] fp16  = 20 480 B  ≈ 20 KB
    //   smem_B: 2 × [ 32][136] fp16 = 17 408 B  ≈ 17 KB
    //   Total ≈ 37 KB  (A100 default limit = 48 KB, configurable to 164 KB)
    __shared__ __half smem_A[STAGES][BLOCK_M][BLOCK_K + PAD];
    __shared__ __half smem_B[STAGES][BLOCK_K][BLOCK_N + PAD];

    const int tid    = threadIdx.x;
    const int warpId = tid / 32;
    const int warp_r = warpId / WARP_COLS;   // 0 or 1
    const int warp_c = warpId % WARP_COLS;   // 0 or 1

    // Top-left corner of this block's output tile in global memory
    const int blk_row = blockIdx.y * BLOCK_M;
    const int blk_col = blockIdx.x * BLOCK_N;

    // Top-left corner of this warp's output tile (64×64)
    const int warp_row = blk_row + warp_r * (WARP_M * WMMA_M);
    const int warp_col = blk_col + warp_c * (WARP_N * WMMA_N);

    // ── Accumulators ─────────────────────────────────────────────────────────
    // 4×4 = 16 independent accumulator fragments per warp.
    // This is the core of fix [1]: 16 MMA ops in flight vs 1 before.
    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float>
        acc[WARP_M][WARP_N];

    // Load initial value from C (D = A*B + C, β=1 GEMM form)
    #pragma unroll
    for (int i = 0; i < WARP_M; ++i)
        #pragma unroll
        for (int j = 0; j < WARP_N; ++j)
            wmma::load_matrix_sync(
                acc[i][j],
                C + (warp_row + i*WMMA_M)*N + (warp_col + j*WMMA_N),
                N, wmma::mem_row_major);

    // ── Cooperative tile load helpers ────────────────────────────────────────
    // All BLOCK_THR=128 threads cooperatively fill a smem tile using cp.async.
    // Tile size: BLOCK_M×BLOCK_K = 128×32 = 4096 fp16 = 512 chunks of 8 fp16.
    // 128 threads × 4 chunks each = 512 → exactly one pass.
    //
    // cp.async.cg copies 16 bytes (8 fp16) per call (must be 16B aligned).

    // ── Prologue: fill stage 0 asynchronously ─────────────────────────────
    // (core of fix [2]: the async engine starts the transfer immediately;
    //  we can do other work before it completes)
    {
        const int s = 0, ki = 0;
        // Load A [blk_row : +128, ki : +32]
        for (int ch = tid; ch < (BLOCK_M * BLOCK_K) / 8; ch += BLOCK_THR) {
            int r = (ch*8) / BLOCK_K,   c = (ch*8) % BLOCK_K;
            int gr = blk_row + r,        gc = ki + c;
            if (gr < M && gc + 7 < K)
                cp_async16(&smem_A[s][r][c], &A[gr*K + gc]);
            else {
                __half zero = __float2half(0.f);
                #pragma unroll
                for (int e = 0; e < 8; ++e)
                    smem_A[s][r][c+e] = (gr < M && gc+e < K) ? A[gr*K+gc+e] : zero;
            }
        }
        // Load B [ki : +32, blk_col : +128]
        for (int ch = tid; ch < (BLOCK_K * BLOCK_N) / 8; ch += BLOCK_THR) {
            int r = (ch*8) / BLOCK_N,   c = (ch*8) % BLOCK_N;
            int gr = ki + r,             gc = blk_col + c;
            if (gr < K && gc + 7 < N)
                cp_async16(&smem_B[s][r][c], &B[gr*N + gc]);
            else {
                __half zero = __float2half(0.f);
                #pragma unroll
                for (int e = 0; e < 8; ++e)
                    smem_B[s][r][c+e] = (gr < K && gc+e < N) ? B[gr*N+gc+e] : zero;
            }
        }
    }
    cp_async_commit();   // → group[0] committed; DMA running in background

    // ── Main pipelined loop ──────────────────────────────────────────────────
    //
    //  Each iteration:
    //    ┌─ ISSUE prefetch for ki+BLOCK_K into next_stage   (async, non-blocking)
    //    │  WAIT  for current stage (from previous iteration's prefetch)
    //    │  SYNC  (smem visibility)
    //    │  COMPUTE on current stage  ← tensor cores + DMA overlap here
    //    │  SYNC  (protect smem before it can be reused 2 iters later)
    //    └─ swap stage index
    //
    int curr_s = 0;

    for (int ki = 0; ki < K; ki += BLOCK_K) {
        const int next_ki = ki + BLOCK_K;
        const int next_s  = curr_s ^ 1;

        if (next_ki < K) {
            // ── Prefetch next tile asynchronously ──────────────────────────
            // This runs concurrently with the MMA section below.
            for (int ch = tid; ch < (BLOCK_M * BLOCK_K) / 8; ch += BLOCK_THR) {
                int r = (ch*8) / BLOCK_K,   c = (ch*8) % BLOCK_K;
                int gr = blk_row + r,        gc = next_ki + c;
                if (gr < M && gc + 7 < K)
                    cp_async16(&smem_A[next_s][r][c], &A[gr*K + gc]);
                else {
                    __half zero = __float2half(0.f);
                    #pragma unroll
                    for (int e = 0; e < 8; ++e)
                        smem_A[next_s][r][c+e] = (gr < M && gc+e < K) ? A[gr*K+gc+e] : zero;
                }
            }
            for (int ch = tid; ch < (BLOCK_K * BLOCK_N) / 8; ch += BLOCK_THR) {
                int r = (ch*8) / BLOCK_N,   c = (ch*8) % BLOCK_N;
                int gr = next_ki + r,        gc = blk_col + c;
                if (gr < K && gc + 7 < N)
                    cp_async16(&smem_B[next_s][r][c], &B[gr*N + gc]);
                else {
                    __half zero = __float2half(0.f);
                    #pragma unroll
                    for (int e = 0; e < 8; ++e)
                        smem_B[next_s][r][c+e] = (gr < K && gc+e < N) ? B[gr*N+gc+e] : zero;
                }
            }
            cp_async_commit();     // → new group committed; DMA for next tile running

            // Wait: all groups EXCEPT the most-recent one must complete.
            // "Most recent" = the prefetch we just issued (it's allowed to remain
            // in flight). This guarantees curr_s data is fully in smem.
            cp_async_wait<1>();
        } else {
            // Last tile — no prefetch issued; wait for ALL groups.
            cp_async_wait<0>();
        }

        __syncthreads();    // smem fence: make curr_s writes visible to all warps

        // ── MMA section ──────────────────────────────────────────────────────
        // 2 inner steps (BLOCK_K / WMMA_K = 2), 16 MMA ops each = 32 total.
        // a_frag and b_frag live in registers; acc[] accumulates across all ki.
        wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major>
            a_frag[WARP_M];
        wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major>
            b_frag[WARP_N];

        #pragma unroll
        for (int ki2 = 0; ki2 < BLOCK_K; ki2 += WMMA_K) {

            // Load WARP_M=4 row-slices of A (each 16×16) from smem
            #pragma unroll
            for (int i = 0; i < WARP_M; ++i)
                wmma::load_matrix_sync(
                    a_frag[i],
                    &smem_A[curr_s][warp_r * WARP_M * WMMA_M + i * WMMA_M][ki2],
                    BLOCK_K + PAD);

            // Load WARP_N=4 col-slices of B (each 16×16) from smem
            #pragma unroll
            for (int j = 0; j < WARP_N; ++j)
                wmma::load_matrix_sync(
                    b_frag[j],
                    &smem_B[curr_s][ki2][warp_c * WARP_N * WMMA_N + j * WMMA_N],
                    BLOCK_N + PAD);

            // 4×4 = 16 independent MMA operations.
            // The GPU scheduler can issue MMA while waiting on the wmma.loads above,
            // filling the tensor cores across the full 4×4 grid.
            #pragma unroll
            for (int i = 0; i < WARP_M; ++i)
                #pragma unroll
                for (int j = 0; j < WARP_N; ++j)
                    wmma::mma_sync(acc[i][j], a_frag[i], b_frag[j], acc[i][j]);
        }

        // Protect curr_s from being overwritten by this thread until 2 iterations
        // later (when next_s cycles back to curr_s with a new load).
        __syncthreads();
        curr_s = next_s;
    }

    // ── Store results ─────────────────────────────────────────────────────────
    #pragma unroll
    for (int i = 0; i < WARP_M; ++i)
        #pragma unroll
        for (int j = 0; j < WARP_N; ++j) {
            int r = warp_row + i * WMMA_M;
            int c = warp_col + j * WMMA_N;
            if (r < M && c < N)
                wmma::store_matrix_sync(D + r*N + c, acc[i][j], N, wmma::mem_row_major);
        }
}

// ─────────────────────────────────────────────────────────────────────────────
// Previous version (v2: smem tiling, no pipeline, 1 tile/warp) — for comparison
// ─────────────────────────────────────────────────────────────────────────────
#define V2_WR  4
#define V2_WC  4
#define V2_BM  (V2_WR * WMMA_M)   // 64
#define V2_BN  (V2_WC * WMMA_N)   // 64
#define V2_BK  32
#define V2_PAD 8
#define V2_THR (V2_WR * V2_WC * 32)  // 512

__global__ void gemm_v2(
    const __half* __restrict__ A, const __half* __restrict__ B,
    const float*  __restrict__ C,       float* D,
    int M, int N, int K)
{
    __shared__ __half sA[V2_BM][V2_BK + V2_PAD];
    __shared__ __half sB[V2_BK][V2_BN + V2_PAD];

    const int tid = threadIdx.x, wid = tid/32;
    const int wr = wid/V2_WC, wc = wid%V2_WC;
    const int row = blockIdx.y*V2_BM + wr*WMMA_M;
    const int col = blockIdx.x*V2_BN + wc*WMMA_N;
    if (row >= M || col >= N) return;

    wmma::fragment<wmma::accumulator, WMMA_M, WMMA_N, WMMA_K, float> acc;
    wmma::load_matrix_sync(acc, C + row*N + col, N, wmma::mem_row_major);

    for (int ki = 0; ki < K; ki += V2_BK) {
        for (int c = tid; c < (V2_BM*V2_BK)/4; c += V2_THR) {
            int r2=(c*4)/V2_BK, c2=(c*4)%V2_BK;
            int gr=blockIdx.y*V2_BM+r2, gc=ki+c2;
            if (gr<M && gc+3<K) { float2 v=*reinterpret_cast<const float2*>(&A[gr*K+gc]); *reinterpret_cast<float2*>(&sA[r2][c2])=v; }
            else { for (int e=0;e<4;++e) sA[r2][c2+e]=(gr<M&&gc+e<K)?A[gr*K+gc+e]:__float2half(0.f); }
        }
        for (int c = tid; c < (V2_BK*V2_BN)/4; c += V2_THR) {
            int r2=(c*4)/V2_BN, c2=(c*4)%V2_BN;
            int gr=ki+r2, gc=blockIdx.x*V2_BN+c2;
            if (gr+3<K && gc<N) { float2 v=*reinterpret_cast<const float2*>(&B[gr*N+gc]); *reinterpret_cast<float2*>(&sB[r2][c2])=v; }
            else { for (int e=0;e<4;++e) sB[r2][c2+e]=(gr<K&&gc+e<N)?B[gr*N+gc+e]:__float2half(0.f); }
        }
        __syncthreads();  // ← blocks ALL threads until slowest load completes

        wmma::fragment<wmma::matrix_a, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> af;
        wmma::fragment<wmma::matrix_b, WMMA_M, WMMA_N, WMMA_K, __half, wmma::row_major> bf;
        #pragma unroll
        for (int ki2 = 0; ki2 < V2_BK; ki2 += WMMA_K) {
            wmma::load_matrix_sync(af, &sA[wr*WMMA_M][ki2], V2_BK+V2_PAD);
            wmma::load_matrix_sync(bf, &sB[ki2][wc*WMMA_N], V2_BN+V2_PAD);
            wmma::mma_sync(acc, af, bf, acc);   // ← only 1 MMA, scheduler stalls
        }
        __syncthreads();
    }
    wmma::store_matrix_sync(D + row*N + col, acc, N, wmma::mem_row_major);
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers / main
// ─────────────────────────────────────────────────────────────────────────────
static void chk(cudaError_t e, const char* t) {
    if (e != cudaSuccess) { fprintf(stderr,"CUDA [%s]: %s\n",t,cudaGetErrorString(e)); exit(1); }
}

static float bench(bool fast,
                   const __half* dA, const __half* dB,
                   const float*  dC, float* dD,
                   int M, int N, int K, int reps)
{
    cudaEvent_t t0,t1;
    cudaEventCreate(&t0); cudaEventCreate(&t1);

    if (fast) {
        dim3 blk(BLOCK_THR);
        dim3 grd((N+BLOCK_N-1)/BLOCK_N, (M+BLOCK_M-1)/BLOCK_M);
        gemm_pipelined<<<grd,blk>>>(dA,dB,dC,dD,M,N,K);  // warmup
    } else {
        dim3 blk(V2_THR);
        dim3 grd((N+V2_BN-1)/V2_BN, (M+V2_BM-1)/V2_BM);
        gemm_v2<<<grd,blk>>>(dA,dB,dC,dD,M,N,K);
    }
    cudaDeviceSynchronize();
    cudaEventRecord(t0);

    for (int i = 0; i < reps; ++i) {
        if (fast) {
            dim3 blk(BLOCK_THR);
            dim3 grd((N+BLOCK_N-1)/BLOCK_N, (M+BLOCK_M-1)/BLOCK_M);
            gemm_pipelined<<<grd,blk>>>(dA,dB,dC,dD,M,N,K);
        } else {
            dim3 blk(V2_THR);
            dim3 grd((N+V2_BN-1)/V2_BN, (M+V2_BM-1)/V2_BM);
            gemm_v2<<<grd,blk>>>(dA,dB,dC,dD,M,N,K);
        }
    }
    cudaEventRecord(t1);
    cudaEventSynchronize(t1);
    chk(cudaGetLastError(), "kernel");

    float ms=0.f; cudaEventElapsedTime(&ms,t0,t1);
    cudaEventDestroy(t0); cudaEventDestroy(t1);
    return ms / reps;
}

int main(int argc, char *argv[])
{
    int M = (argc > 1) ? atoi(argv[1]) : 4096;
    int N = (argc > 2) ? atoi(argv[2]) : 4096;
    int K = (argc > 3) ? atoi(argv[3]) : 4096;
    printf("D = A(%dx%d) x B(%dx%d) + C    fp16 in / fp32 acc\n\n", M,K,K,N);

    size_t szA=(size_t)M*K, szB=(size_t)K*N, szCD=(size_t)M*N;
    __half* hA=(__half*)malloc(szA*sizeof(__half));
    __half* hB=(__half*)malloc(szB*sizeof(__half));
    float*  hC=(float* )malloc(szCD*sizeof(float));
    srand(42);
    for (size_t i=0;i<szA;++i) hA[i]=__float2half((rand()%9-4)*0.05f);
    for (size_t i=0;i<szB;++i) hB[i]=__float2half((rand()%9-4)*0.05f);
    for (size_t i=0;i<szCD;++i) hC[i]=(rand()%5-2)*0.05f;

    __half *dA,*dB; float *dC,*dD;
    chk(cudaMalloc(&dA,szA*sizeof(__half)),"A");
    chk(cudaMalloc(&dB,szB*sizeof(__half)),"B");
    chk(cudaMalloc(&dC,szCD*sizeof(float)),"C");
    chk(cudaMalloc(&dD,szCD*sizeof(float)),"D");
    chk(cudaMemcpy(dA,hA,szA*sizeof(__half),cudaMemcpyHostToDevice),"H2D A");
    chk(cudaMemcpy(dB,hB,szB*sizeof(__half),cudaMemcpyHostToDevice),"H2D B");
    chk(cudaMemcpy(dC,hC,szCD*sizeof(float), cudaMemcpyHostToDevice),"H2D C");

    const int REPS = 10;
    double flops = 2.0*M*N*K;

    printf("v2  (smem tiling, 1 tile/warp, blocking sync):    ");
    fflush(stdout);
    float ms2 = bench(false,dA,dB,dC,dD,M,N,K,REPS);
    printf("%.2f ms  →  %.1f TFLOPS\n", ms2, flops/(ms2*1e-3)/1e12);

    printf("v3  (4×4 warp tiles + cp.async double-buffer):    ");
    fflush(stdout);
    float ms3 = bench(true, dA,dB,dC,dD,M,N,K,REPS);
    printf("%.2f ms  →  %.1f TFLOPS\n", ms3, flops/(ms3*1e-3)/1e12);

    printf("\nSpeedup v3/v2: %.2fx\n", ms2/ms3);

    free(hA); free(hB); free(hC);
    cudaFree(dA); cudaFree(dB); cudaFree(dC); cudaFree(dD);
    return 0;
}
